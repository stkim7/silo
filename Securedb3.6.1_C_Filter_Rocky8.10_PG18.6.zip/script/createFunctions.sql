-- /home/dbsec/udf_1 경로용 예시. 다른 경로에서는 MakeFuntions.sh로 SQL 생성 후 등록.

drop function if exists SDB_ENC(text,text,text,text,text);
drop function if exists SDB_ENC(text,text,text,text);
drop function if exists SDB_ENC(text,text);
drop function if exists SDB_DEC(text,text,text,text,text);
drop function if exists SDB_DEC(text,text,text,text);
drop function if exists SDB_DEC(text,text);
drop function if exists ENCRYPT(text,text,text,text,text);
drop function if exists ENCRYPT(text,text,text,text);
drop function if exists ENCRYPT(text,text);
drop function if exists DECRYPT(text,text,text,text,text);
drop function if exists DECRYPT(text,text,text,text);
drop function if exists DECRYPT(text,text);
drop function if exists CHECKAGENT;


CREATE FUNCTION SDB_ENC(text,text,text,text,text) RETURNS text
     AS '/home/dbsec/udf_1/lib/SDBFilter.so', 'Encrypt'
     LANGUAGE C;

CREATE FUNCTION SDB_ENC(text,text,text,text) RETURNS text
     AS '/home/dbsec/udf_1/lib/SDBFilter.so', 'Encrypt2'
     LANGUAGE C;

CREATE FUNCTION SDB_ENC(text,text) RETURNS text
     AS '/home/dbsec/udf_1/lib/SDBFilter.so', 'Encrypt3'
     LANGUAGE C;
	 
CREATE FUNCTION SDB_DEC(text,text,text,text,text) RETURNS text
     AS '/home/dbsec/udf_1/lib/SDBFilter.so', 'Decrypt'
     LANGUAGE C;

CREATE FUNCTION SDB_DEC(text,text,text,text) RETURNS text
     AS '/home/dbsec/udf_1/lib/SDBFilter.so', 'Decrypt2'
     LANGUAGE C;

CREATE FUNCTION SDB_DEC(text,text) RETURNS text
     AS '/home/dbsec/udf_1/lib/SDBFilter.so', 'Decrypt3'
     LANGUAGE C;

CREATE FUNCTION CHECKAGENT(text) RETURNS text
     AS '/home/dbsec/udf_1/lib/SDBFilter.so', 'CheckAgent'
     LANGUAGE C STRICT;

CREATE FUNCTION ENCRYPT(p text,s text,t text,c text,opt text) returns text
AS
$$
DECLARE
	RES TEXT;
BEGIN
	select SDB_ENC(p, s, t, c, opt) into RES;
	IF RES = 'KSign_Exception_3' THEN
		raise exception using message = 'KSIGN_ERR ... Can not found the Key',errcode = 'P0001';
	ELSEIF RES = 'KSign_Exception' THEN
		raise exception using message = 'KSIGN_ERR ... Please Check the log file',errcode = 'P0001';
	END IF;
	RETURN RES;
END;
$$
LANGUAGE PLPGSQL;

CREATE FUNCTION ENCRYPT(p text,s text,t text,c text) returns text
AS
$$
DECLARE
	RES TEXT;
BEGIN
	select SDB_ENC(p, s, t, c) into RES;
	IF RES = 'KSign_Exception_3' THEN
		raise exception using message = 'KSIGN_ERR ... Can not found the Key',errcode = 'P0001';
	ELSEIF RES = 'KSign_Exception' THEN
		raise exception using message = 'KSIGN_ERR ... Please Check the log file',errcode = 'P0001';
	END IF;
	RETURN RES;
END;
$$
LANGUAGE PLPGSQL;
	 
CREATE FUNCTION ENCRYPT(p text,s text) returns text
AS
$$
DECLARE
	RES TEXT;
BEGIN
	select SDB_ENC(p, s) into RES;
	IF RES = 'KSign_Exception_3' THEN
		raise exception using message = 'KSIGN_ERR ... Can not found the Key',errcode = 'P0001';
	ELSEIF RES = 'KSign_Exception' THEN
		raise exception using message = 'KSIGN_ERR ... Please Check the log file',errcode = 'P0001';
	END IF;
	RETURN RES;
END;
$$
LANGUAGE PLPGSQL;
	 
CREATE FUNCTION DECRYPT(p text,s text,t text,c text,opt text) returns text
AS
$$
DECLARE
	RES TEXT;
BEGIN
	select SDB_DEC(p, s, t, c, opt) into RES;
	IF RES = 'KSign_Exception_3' THEN
		raise exception using message = 'KSIGN_ERR ... Can not found the Key',errcode = 'P0001';
	ELSEIF RES = 'KSign_Exception' THEN
		raise exception using message = 'KSIGN_ERR ... Please Check the log file',errcode = 'P0001';
	END IF;
	RETURN RES;
END;
$$
LANGUAGE PLPGSQL;

CREATE FUNCTION DECRYPT(p text,s text,t text,c text) returns text
AS
$$
DECLARE
	RES TEXT;
BEGIN
	select SDB_DEC(p, s, t, c) into RES;
	IF RES = 'KSign_Exception_3' THEN
		raise exception using message = 'KSIGN_ERR ... Can not found the Key',errcode = 'P0001';
	ELSEIF RES = 'KSign_Exception' THEN
		raise exception using message = 'KSIGN_ERR ... Please Check the log file',errcode = 'P0001';
	END IF;
	RETURN RES;
END;
$$
LANGUAGE PLPGSQL;
	 
CREATE FUNCTION DECRYPT(p text,s text) returns text
AS
$$
DECLARE
	RES TEXT;
BEGIN
	select SDB_DEC(p, s) into RES;
	IF RES = 'KSign_Exception_3' THEN
		raise exception using message = 'KSIGN_ERR ... Can not found the Key',errcode = 'P0001';
	ELSEIF RES = 'KSign_Exception' THEN
		raise exception using message = 'KSIGN_ERR ... Please Check the log file',errcode = 'P0001';
	END IF;
	RETURN RES;
	RETURN RES;
END;
$$
LANGUAGE PLPGSQL;
	 
	  
