SecureDB CS 3.6.1 PostgreSQL C Filter

대상
- Rocky Linux 8.10 x86_64
- PostgreSQL 18.6
- RN01080034, 기존 BC카드 PostgreSQL 15.4 패키지 인터페이스 계열

구성
- lib/SDBFilter.so: 버전 파일을 가리키는 심볼릭 링크
- conf/sdbapi.conf: 설정 예시. 운영 중인 설정 파일을 덮어쓰지 말 것
- script/MakeFuntions.sh: SDBAPI_PATH 기준 SQL 생성 및 함수 등록
- script/createFunctions.sql: /home/dbsec/udf_1 경로 예시. 다른 경로에서는 직접 실행하지 말 것
- doc/: 설치 안내 자료

적용 전 확인
1. 기존 설치 디렉터리와 PostgreSQL 함수 정의 백업
2. 실제 설치 경로와 SDBAPI_PATH, lib/SDBFilter.so 심볼릭 링크 확인
3. 고객 정책·에이전트 접속 확인 후 시험 데이터의 암호화·복호화 왕복 확인
4. 적용 후 NULL·빈 문자열 및 기존 암호문 복호화 확인

주의
- 기존 RN01080034와 동일하게, 존재하지 않는 정책으로 암호화를 호출하면 입력 원문이 반환될 수 있음. 운영 정책 및 호출 결과 검증 필수
- 본 패키지의 시험은 Rocky Linux 8.10/PostgreSQL 18.6 시험 환경에서 수행. 고객 운영 정책·암호문 검증은 적용 절차에서 별도 수행
